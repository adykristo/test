# KlinikFisikapku — Soal & Pembahasan OSN

Website statis untuk latihan soal OSN Fisika, dibagi 4 halaman: **Home, Latihan SD, Latihan SMP, Latihan SMA**.

## Isi folder

```
klinikfisikapku/
├── index.html                 <- halaman utama, jangan dipindah dari root
├── README.md                  <- panduan ini
└── data/
    ├── manifest-soal.json     <- daftar semua soal (edit file ini untuk nambah/ubah soal)
    ├── soal/                  <- gambar soal (6 contoh placeholder sudah disediakan)
    └── solusi/                <- gambar pembahasan (6 contoh placeholder sudah disediakan)
```

Soal contoh yang sudah ada (masih placeholder, bukan soal asli) untuk 3 jenjang: SD, SMP, SMA — masing-masing 2 soal, jadi kamu bisa langsung lihat websitenya jalan sebelum ganti dengan soal asli.

## Cara pasang di GitHub Pages

1. Buat repository baru di GitHub (Public), misalnya `klinikfisikapku`.
2. Upload **semua isi folder ini** (bukan foldernya, tapi isinya: `index.html`, `README.md`, folder `data/`) ke repo lewat *Add file > Upload files*, lalu Commit.
3. Buka **Settings > Pages** di repo tersebut.
4. Di bagian *Build and deployment*, pilih Source: **Deploy from a branch**, Branch: **main**, folder: **/ (root)**. Klik Save.
5. Tunggu 1–2 menit, website akan aktif di:
   `https://<username-github>.github.io/<nama-repo>/`

## Cara menambah soal baru

1. Simpan gambar soal (foto/scan) di folder `data/soal/`, dan gambar pembahasan di `data/solusi/`.
   Format boleh `.png`, `.jpg`, atau `.svg`. Nama file bebas, asal tidak pakai spasi (gunakan `-` atau `_`).
2. Buka `data/manifest-soal.json`, tambahkan satu blok baru di dalam tanda kurung siku `[ ... ]`, contoh:

```json
{
  "title": "Judul Soal",
  "topik": "Nama Topik",
  "tanggal": "2026-08-01",
  "jenjang": "smp",
  "soalImage": "data/soal/nama-file-soal.png",
  "solusiImage": "data/solusi/nama-file-solusi.png"
}
```

   Jangan lupa tambahkan koma `,` setelah blok sebelumnya kalau ini bukan entri terakhir.

3. Field `"jenjang"` **wajib** diisi salah satu dari: `"sd"`, `"smp"`, atau `"sma"` (huruf kecil), karena ini yang menentukan soal muncul di halaman jenjang yang mana.
4. Commit perubahan `data/manifest-soal.json` (dan gambar barunya) ke GitHub. Website otomatis update dalam semenit, tidak perlu setting ulang apa pun.

## Mengganti soal contoh (placeholder) dengan soal asli

Placeholder yang ada sekarang cuma gambar teks sederhana. Untuk menggantinya:
- Ganti isi file `.svg` di `data/soal/` dan `data/solusi/` dengan gambar asli (boleh format lain seperti `.png`/`.jpg`, tinggal update path di `manifest-soal.json` sesuai nama file barunya).
- Atau langsung timpa (overwrite) nama file yang sama supaya tidak perlu ubah `manifest-soal.json`.

## Catatan penting

- Nama file & folder **case-sensitive** di GitHub Pages — pastikan penulisan besar/kecil huruf di `manifest-soal.json` sama persis dengan nama file aslinya.
- Kompres gambar sebelum upload (terutama foto dari HP) supaya halaman tidak berat dimuat.
- Urutan tampil soal otomatis dari yang **tanggal terbaru** ke terlama, jadi cukup atur field `"tanggal"` (format `YYYY-MM-DD`).
